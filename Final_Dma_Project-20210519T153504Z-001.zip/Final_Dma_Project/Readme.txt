﻿Dataset Path


https://www.kaggle.com/c/riiid-test-answer-prediction/data


Problem statement link


https://www.kaggle.com/c/riiid-test-answer-prediction


Team Information




Name
	Email-Id
	Phone Number
	Sumit Kumar Singh
	singh.sumitkumar1@gmail.com
	7004949720
	Sneha Majjigudda
	snehamajjigudda@gmail.com
	9108358068
	Swati S Mugda
	swati.mugda@gmail.com
	9620594795
	Naveen Kumar
	naveenarali01@gmail.com
	9113073303
	

How to run the notebook


1.Download the dataset from the above link.
2.Change dataset path in code.